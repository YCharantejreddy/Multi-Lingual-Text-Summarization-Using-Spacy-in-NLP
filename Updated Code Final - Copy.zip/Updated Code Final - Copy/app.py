from flask import Flask, render_template, request
from textsum import summarizer

app = Flask(__name__, template_folder='templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/testcases')
def testcases():
    return render_template('testcases.html')



@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    if request.method == "POST":
        rawtext = request.form['rawtext']
        language = request.form['language']
        
        supported_languages = ["english", "hindi"]
        
        if language in supported_languages:
            try:
                summary, original_txt, len_orig_txt, len_summary = summarizer(rawtext, language)
                return render_template('summary.html', summary=summary, original_txt=original_txt, len_orig_txt=len_orig_txt, len_summary=len_summary)
            except ValueError as e:
                return render_template('error.html', message=str(e))
        else:
            return render_template('error.html', message="Unsupported language.")

if __name__ == "__main__":
    app.run(debug=True)
